<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'cb015355b2533955184fd4196d359c1d',
      'native_key' => 'core',
      'filename' => 'modNamespace/e954b3c4749f1ba1a8ca068f816603d2.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '460fa4d34f6e214fdbc372c86592f36c',
      'native_key' => 1,
      'filename' => 'modWorkspace/f9b3e8f7c1127ace3f8ac8295b5c29f3.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '366f3abd385b7d4e918c5cbe36f43675',
      'native_key' => 1,
      'filename' => 'modTransportProvider/1b074171a00f043a8d40328a07ba6859.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '473e226ba407ab8a9dbcfc34cc5bd544',
      'native_key' => 'topnav',
      'filename' => 'modMenu/a00ae978b4d42d5be75235eb81c808e7.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7b41a1e970d34b513b811df0bf669d5f',
      'native_key' => 'usernav',
      'filename' => 'modMenu/deabbd8dad90218ff2aa3993cc98c85c.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '93adb87ef4e86457c636da19991033dd',
      'native_key' => 1,
      'filename' => 'modContentType/d78bc89f109faeb5cae9a31ef2893c13.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'fa1a0d73cd2b9d3d14df5c20937d742c',
      'native_key' => 2,
      'filename' => 'modContentType/ea5e8a041e95398ba464013b3bec18eb.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '671ce73492b7b9ac50bb0ed2d1089414',
      'native_key' => 3,
      'filename' => 'modContentType/4d24ba6d611ad17c0b12646c6774e4d7.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e4c8343829480202e54343f111b21e20',
      'native_key' => 4,
      'filename' => 'modContentType/04c39ee4e6480d445346fc913e508327.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a9481e64f8b51b544a47cefc5da91771',
      'native_key' => 5,
      'filename' => 'modContentType/c35a6bfa1c24bbfd548b10f6fca11024.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '17bd58765dbd5f3443cc20580f26bbff',
      'native_key' => 6,
      'filename' => 'modContentType/7807fc6fb9e5f67ba0bd53dbddb995d9.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '90e5ade40c8df6d76ba46418f8e7339a',
      'native_key' => 7,
      'filename' => 'modContentType/fbf35dad7d21e62011f95394db8dceeb.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '764b47a4eb7bf946f6a0be3fddb275b0',
      'native_key' => 8,
      'filename' => 'modContentType/7813e14fd6d2ef59993fa6ca83c3a1b9.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1bd21fa5c08868b48394ea7fbca42f68',
      'native_key' => NULL,
      'filename' => 'modClassMap/78187222d6abf8f4e20aa7585c065444.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '27df2431948180198becebd59fc0b44c',
      'native_key' => NULL,
      'filename' => 'modClassMap/9e74055342121b1dff960f32fd50de0e.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2116a6a88f4560a91b70f0ee793deaba',
      'native_key' => NULL,
      'filename' => 'modClassMap/f64a5d437ebabf66bf4504cf309311a8.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f79574315bc3af83902c7d6592cd9e25',
      'native_key' => NULL,
      'filename' => 'modClassMap/ca116f8e4c92c8befe5677f5d274cc5a.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9765ad1861d496c81c0b69006b17aba5',
      'native_key' => NULL,
      'filename' => 'modClassMap/15b4bbd1d1c8afe53b5f31a132e80cf3.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e2808a123ab600dbd6ee2a4e51d6cc26',
      'native_key' => NULL,
      'filename' => 'modClassMap/782804531b7ed4b9c2d124959e95a0de.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9eec21a490f48aeb6e4c682ca826c794',
      'native_key' => NULL,
      'filename' => 'modClassMap/d83d6b1224ff7964e972ed069e02a010.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f2fc0687627f6b1959f8568b5f6c266c',
      'native_key' => NULL,
      'filename' => 'modClassMap/663d67183e73260a09f616e047f18f31.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5589d06398c378863b8df589c12dddcf',
      'native_key' => NULL,
      'filename' => 'modClassMap/de272839c51ea8f582bf9e546faf95d9.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1173ce759ce51432edaf3b317ffd408f',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/6289ae66b4638a940371b1a8b8343a84.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d952d6729d41b4fb5eb754ee8861d93',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/a41b28e8c78aee2739d03ef2c1adbb98.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '573770aadc2762a92f2e2de44bc2b681',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/a33979476c872870929070bbba7d8366.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '695fd769542160e0862f7d9fcbe4ac7f',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/12c9a2b38d6c22f1e8834841897d5c23.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '20d4a685d862f0a7e54a1cfa1e6c42dc',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/072255d860f2941cacbb4a21e1cca15f.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07461e23164dd48ad794b36c7fec3dc4',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/d0b0c542863ae6e7332faf380ef2b6ed.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37618bf177baee15ce44e80a43b664a2',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/58f9306bfade28fe4a0a9dce059c4ee7.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3d26cbdbfeef6ea723c6b68f604ed51',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/88eb480db89471716cb3a0904a128814.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69d93f1090cc2df3b88d36f8ee27be4a',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/b5477f6586674646bbb3910404ee863f.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45dd75c59af4b23dc0001bdb377317d1',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/3803164d98201cf67c540058f67fdddf.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd14b759242aa2dec28322c6b599269ff',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/aef7acfb2b0c35280016abc1a4d30b3f.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a17a1c5e0d8b9575f79e7d8a4a1078f',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/3a12005f4f5402e4ff6f8fb28c86c786.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd35bdee4deeef5ff46f3a01e855c02af',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/08c636ea0e94831386f476a927180d13.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '096977ab8a3c9d9cc2855dc43d459e84',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/8f8848a84e2052f0d43adc34d2f143d4.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c9c4d2b9c29e48fcdae166b280248c2',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/d449e43f2cbfaec83ae786559ac66301.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7095d8ec40483b3f3317cc38f0e99230',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/15018571cbe6818f45c47548360cb9ea.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af13db8b0a1b39db3909ec3e745bb77c',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/bbfd445cf7da1b0b11afb908b02cf6d9.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42d6e0e7cdcb3ec8a6e62bbba0f786fb',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/dfd6d2fe4ffe4f14a58c1e17f4f844f3.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '907c504bab101ede824ba6648c2b49eb',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/eb68b71d0d00f40039b5db23064be1a1.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c51f3433099132055e3f755c8624d58',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/cf8cef58322349e08a25ccd0895ca9c1.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e1afabedcdf554b8bbe7ff6bd00b68c',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/6c4afb8065f4457be0a6e37d183cccd4.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '868b417b106a4ee7365d0889b19987c3',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/622c7c6d6f61dd8ab03dd0567419bb5c.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbb157759db05f00a5a8093f9d5270e7',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/e7d40bf4f690cf7236ed0687dbd4af43.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2de6029ce0bdb966aa07ca47fb59b270',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/3ae64dc5bba3a9786fe2f093255d6b51.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f5c8c47d8926df73c22d3bad1aaf151a',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/1cdc98629de47c46aaff5b3b4719eb69.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d36fc6165a8e4b2f8c04e949aa2a3aa',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/460f2ad24b5b5b7773889fd4beba1e45.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25051b4bd3a739b953d6ce025b02b708',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/ccbce3c80ace650b2ac12c0e60ecb4bb.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd2e643bc350c9b5aea643488003a0fc',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/de38a9ea4dae1d7b9110aab6c51fa771.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac9741f9e402306a94eed05152ca5a8f',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/a7cfd9181ea05b93ff3d9df0c27a4965.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '01957a17bacd252ebd72481e3b80fad8',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/8e6eff82d34a9259b3d53a22c238c07a.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c235c90ddc8896cc95fc23b0bbd9a2cb',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/9765f2ea951ab9e12cc6548feadfc58e.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f75cbbf05b3e69b36201d6a15c2f541d',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/c7735d1f3b72f1aef7d948267d2758a3.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2c623d608b728c14a6149407e615d88',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/8b61b243d777d9cd5a74e28ad6d676a1.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99862bcc6dfc889aaa0d637668e96055',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/57f381423b2b969ca58018a4a2ceab82.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '231955dba6ca10a34e2f0a1f229723d6',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/960af305b93ea9816bf20b310ee3063d.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c790ec2d89c4c95b6f3dc282ccf8c358',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/497fbd9e56cd7306881683a25d793909.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e81a10a27b7f9388989641f37bdb4887',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/56f7002e631f91b5ae49e905195b3b93.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '12ed511bd86a175028cde3b75efaf490',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/6a44c08b7d513d9dba634935299fe8ea.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec54ddbba6cf818c773ec02dd114818e',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/13db7f9214182d61af2594b312ff1ac2.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c31df5ace645ad373db5cc1a0acc2cd',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/c53984eb176a9eee5e0d409afddb04eb.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73b819b1db19de316ef184bc7874e7cf',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/0b3409c2da8062a69efdc083f73f657c.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb06d37433f91d1321ed0fe0c7f919e4',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/72adf64b5685c90ac313edd3f10b0cd5.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c67f4c224bdfc141f0d95496fe20cbfa',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/3b41f0c2a17eb8dff16ce1cb708ba628.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b84ccb1476d886d2007bb3557b9c64c8',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/3057f260221e2c3ddb52ab38bec5fc53.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2af136205c1f9f4a09fd502924a24330',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/d20bb52ee455e0775bd923031fdd1f02.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c105fa06f434174b2e968c8e139b9936',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/0ce5d90990f735b09ad6f17041a65e57.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56cda161702415641de7102793dccfd2',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/f8f251cded6ca891fcec504825916275.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1bd86b4dde5133388375ef32bfb72b9f',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/bd61e43d00c84fadfb95b914b4fc4b8f.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a90f16ec1fcb528227192ba57c4f5e3',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/505d803a6cba2ba94902b9d754962405.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f217caef62b4f607213e7eae2b7d577a',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/6c9b1dfa2d9c7ce643e56d8efcbed091.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dee810647ef8d8f9404aee7e52545e8a',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/3e95899e21c5330ac28f1d13072cc30c.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '034305e5ed253d6354a2bc9f112c5809',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/2c6124db1a6765c25a137e1ec77e0624.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4f40d53390654657e475384217165a9',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/e690110f54792819be88bdee15205efc.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a3a374b448f302ddd62d969ee5846b4',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/26fbeee3c414842785f31e2b5f7e36bc.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '955eaf5379d342f087766f874c17910f',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/b806ab3e84d5746cdc5fb774eca43f32.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3b29f55137658d19e2dea07f662be6a',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/8d2ba3c4585acab5686ef1705426f203.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f12faeaa7a970892e87eeb2a4b645714',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/08c66ce8ae6933deb4cd0ee088492725.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a4135ad0da361ed53be421d4215adb2',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/39e0e4078334f4ee5cd757a6d61d2706.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ecf5a825c2d8cc5706fbe9f8b0fba634',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/c4ef42d802cea443cfcf93da96ba3a8e.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b9574252a6ee9da6a2dc1f98c7bd9a5',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/7956715836b8c4732e0c6b1e99313303.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b6487c3f15a0bb91cfbe5d45f12b335',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/6d2d546e96485c4dc8ab9d44f22a5ea8.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc6df24a508b8d75d4034deb8602472d',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/1cd5d65abb7a305bbd3c0de078af9307.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '998d782195178b848fd2bde20230257a',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/03132233726d4c2c762cd9d6af788643.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8781cb8d0c5ec8f2c4cda608ed385f07',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/ae5c10d8473849c239ed4c4b0ef143c7.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0d8210107ab29bb09c9fdab790ada41',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/eb1dbc1c4c05e38107daaca6cec8cdcb.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b1a0c49f8dfaeb737176790f919c2e8',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/98e1b7e4eb0d86b5dfc6d3074df32c9c.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c06a67514f8beb12b4c918e7832a886',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/64eb914292b36487977a3e654eb81023.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a791b7fa50aef885d3071e80604ca3af',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/9459c590fb078aaf14f0c857ae6b11a7.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d61fba58fcb36c401ea9b519f38bcdd',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/38847d1c363d13866146836debb295ec.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe9e92d5995c0f714078c1f4420d9a10',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/fbf689b9f214f47d377ff5f49568f8bb.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd7f99e4e030a624bc19f90151cae0c9',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/778f588e7409a9fa0038b3ee45754b3f.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c87dc040247d2626e6699f1208c523aa',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/c30c3dc9a162649bd004a2d28753d387.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f1153d4935d9ffaef0da7d00ea9976e2',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/f0c114e46b6b23220430ebcf3100aacd.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2acb561493a1695385547e2236c41015',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/3705ad251366e747e5bc145286f51765.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '080d8289f668be6388e9d2f5c6c9da20',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/4e06b1f1e1700a932b6cfa16694c8a27.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da5c53bdd2e26106796a773677ef6d31',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/e049841b1e7f04fb2e1336c305122b4b.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44d92ed9231ba84830a183a8408e314b',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/5b487f7c5a8db59d379ab3f4454b563f.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '789d4b1b9c43d69cdf7902cc40b9c589',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/0bff428767da5dec188e71f3f475774d.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8e39d193b3f1787f24b6752fc6b955c',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/d8090a98db5ffe724388a0bd5bf621ef.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0c948aea46f1cf86983841a9074753f',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/e3337968dd66ba77aac66b4504de9399.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d39528baae1ca4b4af1571f8496574d',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/3b9294cf319f9e8b5871f82e9352cd28.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '60b245523f23ee54441d1e89ec7d499b',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/5d49b4c1a746186d821a3097bb8fd698.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14bd8b9ae6a36d47a8196d3865b82a6d',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/1ba840bdf61f309e3854764ef19b9b9a.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f151d9211c09dcea892a048086f03657',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/239918db172c47e60c7981ce1f07efc8.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7a92e0101fe6b2c160e0c49fc112b7a',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/bc381534bfcce7c2f51044585bffbac6.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f069e46be59bfd3003278c63ce21b22',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/bbc4906a742bc1a696a869f8b9434dba.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6564e100c9462ea264ffe050b98ddf41',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/d5f45af2f2fa02862525361988450075.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ff53e202b232efa4879744bbea47384',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/02a3a3e98a04def827299a158017f088.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f4664645214c7b5e95b817a02c5a466',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/73e46bd79c97cf4c437745ae738ad311.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52a16d6d3940d88a077d11751d49c280',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/f90d8740d7ec835e2939ac3503460498.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56fd4278bb055403d1cff9aa9bb5e071',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/e95c8c789953ac878fa42529cfc8c04b.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e71a71ce0e1013d5ac5a9ab7480d8d15',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/839c77cc76b4501231947048fbdc95a4.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a15b9a712a46d9675143b80b40db76e7',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/3a6c9b41f5e21e1ebe7414ef2ec70eae.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea9bf044eba55c0bdfa09cd03b030c06',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/df4ecafc0cc080d06806597b627ca9c1.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5ef750ae10f5fd4597ab14c6a77174ca',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/19817596a96e11e813046c3577d44f91.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4fdc827dcedf1f6a9a96eddbd162066',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/a0e718dcd566ca001eb7a9c179edef5f.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a52683fe0f64910e75d7ece8e0ebdebc',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/c6a75ec3a0b65df1d7c2190ca5961c22.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c3d73b8c4292483df5801a53335147b',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/d679733d058ed81b243b4ba73a9e5490.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e700511f4562c205d34db2e2ab388f6c',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/13e2a72ecfb36ee41d01496c841bfdc3.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'def3073600d62802e61ab174898f2e3e',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/adaa1aa33b69e17606d987328e1fbc38.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2cff2f460fc9e7a73652beb48de4643',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/8b98fb8cb8aea041096ac7ac615e68bc.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98a459ff4fb2d89cb81f8b1f36127064',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/2a6c2888989d2a444a09c284a9692070.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0fb4e28b37ff502de95f8b82f04947a5',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/9fbb0f38947b43edf19156073d38e669.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9aab46b8e14974b45ab8e849de13814e',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/f2bc051512a570772d8c9c0c71157c35.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e3c9fe25572959c82fe9c85a2a1ceef',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/87bf999bf6c5f199475dc63e91906643.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b047b83ddd1e4bdc7c70f91f6b08b124',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/573a029b095d4dc41096bcc5b12fd657.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c649d52642e0ab64f1651d5216da9d6c',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/70e6af9ea1d4d231365696772ed0f79b.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '710ca5799f2eaef5043b7cb486ed1206',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/5908a0387bae142c9099eca3f3bbffd6.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c46ec449919c84c059eab16052dda41',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/a9923fb0275613c4dbfd5c1dae80c71b.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ecc31aedc1b712bce3bb8001810a904',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/fed39028dcc20e18a11c4ff68be3942d.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ecb8e4a1fefd8ba14f3c67df3d6f1877',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/c578d410cc51dd8a75bf942647784a70.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '863a8ff46f08ea4c75c79fb030bb03ea',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/63da618b7434b09d8110c144ecf24d71.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58c4b8a0dc9d114863db5b203493ffd0',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/925376b1578c654393f2087238e17af4.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d495a38e93c85f88070cce4300e2181',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/5daf38011f15a4ee5de3fe612fe2d7f4.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49856589346fd28d6a4ac31518194c63',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/1c3043df33aa0609ff7284f2ebd9fa8b.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '781505a47d515dd5219db3b34faf0d5e',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/3fb87a2a72f820c7c23412c2effdf0cf.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5651989f7248079ac263fb1d1380cc22',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/fe9e3f55073abc50344d2b4c615b2400.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8995a3f72bf76b7620f7971da4e7f3e',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/c5ac1396a0b0e7f857edc0dc29a8059c.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '772c05960026ab42e0d62099444b1010',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/d75e5f914ddabba9a43923571f89c183.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aba6ac6c16300fe42d50da628d320116',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/9556c68ea1dcc827bf7af8702cf9000a.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a21b750a487342fb0841a428251796aa',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/23ae1be6f810f5d2069a5e3dd52c9033.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dad0282f3cee6e14cc2a67aab81e4ce5',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/8f9406315a4ee2d56e3a183dfa4e6320.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea8af3494023046950a3991b7cb2d302',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/1b49defc91bada06e8ddf19608afa552.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ffb4ee419671d0eb2da9e56a0093ff0',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/ad6b196ddce7e104ed7e0ea5b2a85fae.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e342cdec53b1d6c7b92098e1d4f7be95',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/528b7482640e89b6ef9e9a3770319630.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '444ba07a0b43b7e5d45599dd823f5158',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/e91d0562ca62aa70d31446da5ccd27a4.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7644695eb0b9a5e51873168714489aac',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/70a08874158c24559eea2013b65e966f.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e38b5383afe3dbb3c7f853fc015373be',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/106440de3fd9abdc05e8e95c0ccc3c1b.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f60c73cd0b4127ed380808e31d970829',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/b8516b5bb8c4fc7bf9982e33f6957451.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9802faa5da99020e4f5edbd1cdc17560',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/c4b9267cb54116ee568c0f2aa4450cfb.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7afbe4fdcc5ab0c3dc72f3d986ad0afc',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/15f954823112b2eba881ccc66e245e83.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2aaac05b63b71674f8664f5724350b41',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/db4f02863532d2c4f5d9a4d05a225ab6.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31df3e298bca1cf1ba2236ad9d34f300',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/1630cb29eab313ba13d36e50c21928ec.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c4e8530ad775f38d65bc7dbd8953f15',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/3572f22e1a1ed9b1aca5bcc4b248feaa.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c40b0bf182cd7c069115d1d6bc32b464',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/c75803bbf83bd2d98aabe0b1907c815c.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6d96c4d352d9286b47e5dba3bb881f6',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/59c5e24cb49525885f13a5ac3e1e36bc.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ae63f2546ce9b0d77dc09ae8c5f8b5a',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/15cdea60baff3ad2987d7cd358c68384.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '405ed4de67fe2324d74164b4b0cd9f0d',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/35f9901ae28ead324fbd666d2b6da2d1.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '592faac71ddf6f5ab0dd87a1cbb4e313',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/cc54eda4946955eed96309ceba9be11d.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2408733d9686c60f150edc0b0b0b3105',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/4ef1681bc1378fe0532bb7019bd45a15.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad6a0761ce96e4f5b9dee6230b9d8dec',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/89542d44425f6643e916311937c69b99.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '165f7985c0c7c3397820e596d5e4fdbc',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/3988f9a3b6de5b5cc99b842abf2da3c7.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f3c69a43fc82e11752a1c89f69b29d9',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/546945d5bad0a996d6bb1cbe0ece8ffa.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64bdf074c1bfa9dda952759790cb4a8f',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/e5f38f5159701143c9b102e569d4c966.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9a632f2e7f7cb65605da8d38137ef8c',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/069a9151e577113dfa68e9b14e6aebbc.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbbcbc32e85a7c277708896010e8d063',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/2d99cabff97c241e897b269d0cf6d79d.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25ede49a8862d54c3ad989780b06891d',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/167cc09d27d0cc605e0356290733b350.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '562c41953c5040307f0169d7e41da198',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/0e1af89c76de854ced36596a4764dedc.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c266ca141d3879a2264b7433a3d13d6',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/efcfb9d034b97210ebab934c11b14400.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5b84948a27a1ebb6a8e5fb931824653',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/e723132ff1c0a38dbb1a8bc2abed1b4b.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c4d5685704026124be048bbca942142',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/b7122d18e98c8dc091f4f9c8d5729bc8.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ecce8f4ce5aa74f8477058ff85553ea',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/52b7d8fdd4abff5d257bc9c72e9609cc.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be4de206b9e55a9533d7a0080888ec41',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/d25e339dc4cc6c33a6dc940366892261.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea82da11aebff33b38aa16801c4c0f46',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/85561211838ee2d3a31cd11b3a6bfd2d.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29a8c3ba4c8f02f61df9cffe833b87a7',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/48b45b2c017427cc0d6ae0618a02b173.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4af15a378fe30ec4ac691c31a0f5bd9',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/b9b314e45e176e7b14bf3c353a080b21.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ddab285448906fcf6bec2b065e9e71a0',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/516a6d25908de6e3588a2098613d25da.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39ef0a66635a03b07369e5f5eee5f93e',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/0e8091f9cdf29dffb16b4660c2cc7157.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5228e2e02ee3e6e206ebefc8c24e27f3',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/42b5498f50b9fe1e3e2ddb4b6e29e2ed.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94d25ace03c5fb15ba94b4ecb1c8831a',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/cd3dfa820c681916660ba3fcc917f862.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7788a0e7c4d0b3dbf765163fe6165682',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/8726886e40de1e234631c5edf3fa0c37.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8cb1147c75ef6079613ec02d48c6e0cc',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/64aa80c537775792283cb0546c1a4c81.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '34b61fd298a32742455d4c64b259013a',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/ccdb1833c43f57c02b3a4a0a5f300988.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ede46529ecbc3eb8918bc78129d12d2a',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/d66b57f3f0ec294b6d126b9dc32d8588.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc7b047c35231f4794c542ae470a8f50',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/ea8c2b1ed659bce9ab5addf8683b344a.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8933938968650135acb54a50f7cd1731',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/98ca87196325017333664da4da88281d.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8bc79576e3e39dabe13c0d63d1b1da1',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/8663512dfceeccd254cedf6a9ce51e10.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3fa688cfc5d037a65414f7b012b07d73',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/ce2f0309d4d5ac6ead07a88c0bddedd1.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa1604f2199977c41f3bb2fcc818837b',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/eba12e7b7649bb6c9a1c5935a1216708.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad6ee516e14ce4880f2c4d7a39234f75',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/bfc319a7b8854f3553808c7e98e0f680.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2554d76dd8875add5ff28b1614a916dd',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/da06696f0757abe7bab61b116affcd7a.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a26fe1b921eb9e15e7248440e0fcee2',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/cb88bb5a64b0a2a53ecb48391cf4ac4a.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '236a02dea0d411b25cd4e5f4e77d26cd',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/5ca2d1a11490bfa31b25e41e2fda4e97.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb92cf96a15969c3dab12f289c266644',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/35a8cdace3d2c5fb9dde27f9cd862ded.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a35e7bdab3d2503d35a47e27e58d2479',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/dc80412da97e4cb010d9a2b67c6fa264.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '470448dac7f3c5c8d0bb8a06a27c95f1',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/b829d52fedba631bd879ca0da35141a5.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b82c4dafcc0b9b193ff07578fe600380',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/7e0c407db4bb2489698115d3cbd15416.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c093a2167f86aeaaa9f2b292ae6b90c',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/adb5dc6599d39018515a9fcb932537a8.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd819f3362c6baa9d80b069fe2beb635b',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/9050553d02ffd45f88df4dbbe56b6b0d.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec9b32cf5e6ab1d59e56e65bcc24e793',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/4b3893084507e1d3ad5b96ffd724d40a.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a08227ed9c55ab8e9cc27ef51a82ba30',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/488d978729a14cc89adcae9f010fc811.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c2989d882385b5f7f153b3e186c9ff7',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/7de24d8fc911eb498bf0f218dbc0db00.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2bf1bfd501580261ce7e16e989f0a608',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/de9fefb23d7740eda04a23413c866eef.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '672d6fe56d5c9115840fb1eb7c844d35',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/292afd4c7ab3df894dd0ee5d497e6f83.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df57248496795817b28bac78db10fdd6',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/c97609af5a31bd99f90929a48ec2fb48.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f11b052b4956faef979421752dd4b5bf',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/c6e3bd9fb53e9d514a13d659a951a342.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5dfc66727c406fc2f8cbb2243f8729c',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/43c9a23a1e23d03edefd29e8d58b7cae.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0acb66dda3510db8cd34e7eba18d14eb',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/8269897fdef05e6d2714f0f94e6fcff9.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd806090b9e4ee4ef73d3b61ff28efad',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/23313e7afb795957d8ca6cce83e74e6c.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cbe577f570bc8f0d91930ac6efb3c4c',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/8c0c0b7419fc9360faa468660193fdd2.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c47728b6f6bb1c9625f597b7b9fd6b03',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/e7c602919f146b423d278f5e5027b04b.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51f590adf1ce981ef4c9a0d1272b2a3b',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/4f07c679d9fab1135f581ff7e8c7f001.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73750fc7db36b7766c47c4491af95afb',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/9dd6f20261b4f82ac743909ce7cc9af3.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e240d71734727338940895c15588c65e',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/0b28e2692f903463dad8ce8e1ba81795.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53c792dcd597f2cac84b6b32c8aeb9b0',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/79ea77f794ab2c133221b92a37b2072f.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'deb831dd0574ddbaabb891aef2c91919',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/5812b270d659aaac5cd2b630716e38db.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a653c5874082514eb2474a35a1bb47f9',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/8b7ad91842f64664dc92e7a973a66c95.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64f23e9b0cc3ca6b7df77d67151bcef3',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/16b0cc51989060fec590e9b5e9467698.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '948e2d6f2d64f76615c9ce0c103b35b9',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/b825f1c60984d50964f026852e7edd5c.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26a979613d860a7eb32ac71ca5e35cfb',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/8466327890c567e838b30c68eee51228.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df304c23cef354c674604b454d27bda3',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/41f73a69c4699e7706d588cd24e48329.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a09f4b3821a38abed24f809f19e56a13',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/36f13f6248276f13a1117e893a45f96c.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ef4bd8af9c81606a0160407196aaa3c',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/1cfce56106ca7e331fcdc77057f96a70.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9367367c24f1895dd7c9ac7b9f840d10',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/dede68e0596184888474cd9db159300f.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e07946da9b79975fabe1a4f7f50f5f8',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/fe05c27086bf80bdb3b010ddf829c1af.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '184168e4593d4fbb08a6d9b9322828fb',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/b28dac49c518d7551508148669d22c01.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e5ed76db24ecdcb90578a4b3407ee84',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/b683ba14a5641e5bdcd2657b6b23d6d7.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a287f7c236fc4183a1542446a43c908',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/652768aeb51398d74dccee8c68d262f1.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd64e0ba0b909097f7d9148e085e06b59',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/4b168408d0d949bb7760d6e6903cbd69.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd10df63e3d9c77ccaab6a29ca4599ca5',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/f0d0f32f5dfa64a70bacadac32da2d2a.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '761fe26484b0475fe0cfa1f3fe9dac3c',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/ee839ee93843336f47acbca46ddd76f4.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7676084cb1427b400c83f32ec4502eb',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/34e4ed75fb4208f973164ca3f97c38f2.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3687046be5710998ce994539b65e869c',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/7b1a8a4d6027ec756555251503a91ebf.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4932c9e1b3d14a74a2f46dbd0bf4f9fa',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/d1bee0498362105c7c78bac485a2ebe0.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c192e2aa17f53fda4393347356fc657',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/ded13625b3a0a00642e5e8c3b90cb81a.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48b1989f02f753fef7d5735803f348cd',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/addbc6a9db4c2fcea97636d02ff364fd.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bbf561f022afaed33fe4bbc7deeadbd',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/ec8765a61dea75bd05163e4914119e7d.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1ab6e478a4fd3f1328fc36024a2f94c',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/c47cb742590fac3e3feba96434efaffe.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '612deea0e012510a413663801e9de392',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/01e32a9f9d849d7f479e75d20e0ebd39.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'adea249e0897f5776399ca2d252d0d82',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/df60ddb6bd623012edf4aa5614d8b11d.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd026d014aa0adac7aa5b98f79a5c83a2',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/efe78f28f8218e3bbf4348d28da255bf.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '249d8f30bc284dba02b645e3629aab4f',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/6417fda126da42387db7bb6c5d43e0a6.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17a3d29005c26d5ad60cfb4ade303700',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/6463035c24b8fad9150bacd55a711eeb.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '099ee3cf9297937e3306c0ed04382150',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/3a3d786f1e3399d357b638549bcebc9f.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44ffbb0012de3b8bd05654dbf8f51a55',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/bbebbbb93eb8f4f87e2b500afe3ea430.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b09bc0340ae9f966edfeeb214f80b40',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/68813398a21167efde56a5133ad7e081.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd296a87ca70d22ddd3aac96570cb70a0',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/f3a65446a2de35074ffb67aea8669a86.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '978d3be9a7dac93153bb732e1589e7ab',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/ec07652ff37f67ff7d1edee68b55f9ca.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90221a9a4bee59af6311d5e77285b52a',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/adb2cdda180651c70d69bd1ce50fa07e.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35f5bc7145b5b9d1d17effb86938cddb',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/e7533671e40746511da5f75198801018.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92c77837ad65f15a38bf3a6960f2e6ad',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/949ebcd72b68446752861b7a84af0931.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b06658082930761cdf1000df641db832',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/87d427107646137d1c53019447ea12af.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '319f0748c774303b0a0b20fb4ebae06e',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/4b2392b8909aa11b388500867108d33c.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02ce0102e32afba0f94626d0d1a20e86',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/54e622ba50dbc8d366305bd38f4d991d.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae80b4e5e9c194f88d0d1530c8f7670d',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/a14c7a5730ebcad746dccedeca5dfdf7.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e22125f6f036e832d473284f1b15809f',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/3ebc648ac13c28f3fdde4c21d824229b.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2c81bef8ec698e4b189fcc61b091ca8',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/c04ef08b0f6f9db4f7ca2ef7f44ef8b4.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5626dcbcc2dec3939dc52ea629230e9f',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/0a715155644a7dfb1402275b8d3c0f49.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '412cc288001f974665d4ec0121f0c87e',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/b9f579b7cc3bbace23c3031c932d2098.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f045a0b1c4162d055e9c2ca1559e7e93',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/436e176d3d470c97a37ac1f584c7b807.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f10c91c73b7b405657e1791812d4e594',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/b6ce30833c833f5345425720cc131c75.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ea55762d472aa2ae2480dd96ef8b204',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/a6c18b1f91d9e759a70faf36d94d1aff.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dea4ba0cbcdd121059f94d9afe0d5a01',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/4c514d0c4d42997c34af4d4657019029.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb6f625db520580471a4be061faabe16',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/d14d53b94340b6ed7add81012b2d87f2.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '848212b35303c4a3857eff89ee51fe39',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/f3c06ff425bdd57074c59dd0c8479083.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60cac1608a85b47628e923be2a0ade09',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/88e924023a7248bd93ee62ebd52db3c6.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7359039fd36c3492e5e331cd63a4feab',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/57ca39f7801bd3d02b873d9ac51a9346.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79abf597b0e385c3eb6d30402c3a5bce',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/464e0e58934669c198d6bf25dd1727d2.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47ea1b7c977c3e6ef63ff5cf0011cebe',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/0de28570c8df2cb544986adefc99cffc.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '458a4566a5f73abe3fac13f5eb82c250',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/c4fc4460b6efd21c8629adef5b1756ad.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '574eb985bc07bb3360753354207fe45d',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/07fc96ec10016960bb49cde62096ae62.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56cc1820c66beb9736966c88904d144a',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/2a3f257200e6c6127101e0d6d312b183.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '103b0f7a73b08d416c4cdefbdfae44d9',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/9f39c78d507b4f86a0718db310f11d71.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c01adcf65603ae33a6a425cf5e123bc8',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/a2f9216283d90a5b4e4a73a978b66514.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f42eef4ddc3937ef197db0860499569',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/9eedf71f56d53effa17a19be1014ea59.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3604d21d5ce118cfd0cb1921d629559',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/15d07acef6c60b4704014e7afffb683f.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f61823148b678e1251dcc9cb6a4fda2',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/7971459b9a3dfd654ad00eea00e26d60.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '283a1de1d7144ed88f5bcf9a87058c72',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/35e795d5084e485b1b344657ea911204.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '209157e0b293a9ad3b0082a8d9687f8a',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/0fb07f5fd49d9b3bb7d23a381d7ab142.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bac14c809b72eac7440aa01faa018a0f',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/dc4c241c9fcf1fe68fa028eaf7838269.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf65f35ebc46792b7fdbe2daa6be94ee',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/0fdaef208fbe97784cf6fe8bbceb1632.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'adb0157210e75e7f51b464e0271f8bb3',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/866b7c2970479f02f6507db945229638.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a55b5d9b7efbeef08e40c8812315137',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/9f91893a6e623e5c3ea0f3c43f3fb0c8.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2cf1cb655e7bd33daeac7a834f0040e',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/ee590fe372e7f403d86cadea3f9663a1.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2aad2ece45b51804834bd63338cda94',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/943951b130aff4264c648ac9daf8ee1e.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41f8555e67c07785402028351727065f',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/9cd877500d7d26e2030fe68b0a49d28a.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '693b326f55598ae97ca18f86f1ccd4a7',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/c7879a3084ad5814633efb6f90f370aa.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2df01b6db32d77e363a2b0579016a9a5',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/fd1ff5f0a7d4466528cae49a7576af4d.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '219908d0f63f80b47efbde7ae79712e4',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/f5cfbcfb312cf713ae40148cb68b3a9f.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53493d5097d58af8df9b14d5ef49d3c4',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/c92f4ff4718cb011869b2f3e41d8c379.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5766fa228400f2021c959d323cebeb2',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/a54b689dd2405804e0e386366e61824f.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5426b4b0932a20b1813c6396219e15e',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/e1a9a5583b911f7fbcb1e3125aec1694.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'daf6a9694e2eb5e873a492919e73109b',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/c1a43af21d3002f1a02ddb5da18eca85.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '459cd189000b35f611b52542c324031e',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/639cb1f24d8c078579df4b101a806ebf.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25f26ae54f034d6c833d3db36e4a447b',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/38b6395fdb6d5b5a7ad7e336925ccea1.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed1b3969f0a5686a4281f247abfda740',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/2f2e8ad270ab9e1fed23924b68c59510.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '892ba2ed69bacb85716675558afdcb6d',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/255413b40355a624649205cc067a31b1.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5dedc3061b573e9f56c02e1e25b1353b',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/730405aabd38a451ee1e34abf4e5d39e.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab032a1058a1547799f602541a4fdb31',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/a2e96da3e8aed44e208e5d18adc7b6fe.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd833465ecd26e602bc4a9400eba26896',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/9cf915857ba5d980f2992f46d92e0171.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30d9333d85a0efb3e5b11dafac102a65',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/d188727009cbe4b7c8917dde9c5e314f.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18f24584e2309d92e165c6e02606aa49',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/4d524e60dd0f469d6e5fa5baa5403b2e.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31acbd678decd4a62cd22ad196b981d1',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/6b27c7dc62d9fd3f75ed15f3d14dbb84.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c4e7493ff55d4bd842433b09ca06778',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/d8a35fbcf1ddde4e52ed0128c039bb1b.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10e87d59472587ed4444b93c6f0c7d77',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/dcf9de8c7c11243c7c4714250f390dad.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca1adf67814a232e6a02a22f8af4557b',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/3f8e5cb9a7ecdf74889098fb5c313fd5.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91db8abf9bab2ead87e78079363dc7b5',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/a3a963cfe9027feee3f63ea41efa3844.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa207d49017d03d66dcf5e5bb7e68659',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/feb91c13364a0995dcc70c954c13398e.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4dca2fec7099d92b4b7de7e7ab16915',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/e2f9df447cfa2985d6598795d87146ae.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43db4582d78be2f294232b5356e8d9a2',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/b78c8b4ae6d08aa2862b5eaa4bbe411f.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef5e595d49aa6e3845e3ffc82b45341f',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/fec484b1d56198a853d7ccb889103e2f.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5caed6ff73995800ee9d3d0dc8357d9',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/fb13f2d4165ba160959daa165e48ac71.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0d61e0d1afc3483f9261db92b9a6c70',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/618107eab7afa535f23268113760cef9.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ccd3abc7029b747a5b9e84973899dba',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/a2b9ea08facd8840f9176b7151d59fea.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '977cfe58da114524e6d0a6ce2d02ce3f',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/1d81f92ef48fa6671afe6ae073c4a463.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46bfa7beaf4d4a7f7e8b8cb558e72f89',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/9360c4446245b896cfc15dfe0aed356b.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a48a9b81ba778ef5706caec45f5d58b',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/83bc7c287072593d252e20f2e6144e19.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f88ee6e3c7c9e792d6f4860a97abe0c',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/535b1710cfdc2cc48976b190168a0ba3.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f802e311e516b15eb01ab9195c0ba827',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/2a16aa8b7ad88f54fa2392ccc0216cf8.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e28a42990ef8bae0e224fe8a622e6492',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/39bd7bb8a884a7f0003de9df0d48939d.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6b67c5fcabe970f78ffa24f28d79381',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/f5df151ab8757e7cd80c815540335cc0.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '022ee86935336d690f9b406a424ab781',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/9f9600ef9ad451320467ea6ff93163a0.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '152b20b732ffdbffc19ee551130c5952',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/7cc37047c61eb77c4de335ec5b0605b4.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb6c730e0e8c28656ab8fbf2e4781e84',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/65dfa66a80861dd7c1f26b3b0438dc54.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c670621c1e3a74331919960b6e816edd',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/d01240bd911858ca6bdc8d15ef17d103.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bae2889ffb1e4e962adcc325def5eb4c',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/4449f1ae2772c1115ca4eb145c76d141.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32df325db79978613883da73bc760ee6',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/f3ccd82d2308f769b09cb306e716349a.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a426f13d0d5a86e5ab4bbbc083c4e1c2',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/eb23d593c4cba9f4e944e7de84a39f5b.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b854850aefde4ed636e86032853aeb0',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/565c9c1abcfeafc6f7b99d0090ebe519.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ef895970018f350ffedd5454ef7a966',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/15b4392636c4ecc9478a88e5a9de588c.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc50180bf3b5ea635dabc0a47ed1fa4b',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/81533cdce7a6cffe22d45829773ef22f.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63425d6977eec7aebdf17c6a2f4a5b3f',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/9ea68cd4db5d3669d9fba90e7d335b24.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be92e52db56dcc6e094237f46d6159a1',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/ee1832ea3c85592a0854d0b758fee29f.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d38cb6c1268b5d3f3479e4a55079693',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/b78361eb6576bf1663601ac05560b430.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2aabb4c1dbd56e5657e6ae8c7b7db45f',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/0675f0c377a0d5919bd9da7414e876d3.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7dfc4860493818f1415aaacc581c2875',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/3cb8fb74ed296f2d30c034702d1338e6.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89e628417c3cb4dcb2059b0ee3770d6d',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/5aebc1a71d75df142d5897e837d1ea3c.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b318114b028058d661021538740d79ba',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/b09866e202f3616ea1523f6890d54889.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66e13377d4347eedc844b821dfe754c6',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/0f4d2c4baa8048130261cd53d2a7c185.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4dff43983c60c0f1c99bac97484323fd',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/23da47f7fc9820abb8e23e2fb7d4fc79.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '483a727452d35476d1f0af98cd4d7c53',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/54dc931bf1d7b319f369ffcd151169f2.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a88b6c1fb10372ad117329dc5a1e4b30',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/6558590144a388b1cde5fe2e7362fb3d.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50eac711001c8a27b093468df4838440',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/6ee86b3e66ce85bea88530b8a70158f3.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abb07a59f23c6f70ad2ee0476025eb02',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/8fda1f91152d0ed961ce5f42063237c9.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2fec209800df55d3a794f19289bf7daf',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/7c71fe8c32c5c661a774c3318b39e0d3.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ac3600ec5627a28b0eb78f171e44351',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/b484f818f9ce0387f8d8b93df0cd4cbe.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2879d5183f22dc8f0bb02dc350eee6c0',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/5b4512a2451997957dc41bc46ba3adde.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af16e6461c83c98f54be73a22a28826e',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/f06c148e7e955a3da8e2e32f1bb7cc42.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b03459fe09e484e3c2aa823277af976',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/0f331e15c1de75422dfd0a63c240dabb.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe054084ed26ce94aa1f33e4e5446b68',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/7b05f375d091e0fcaf619bbd25545420.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5a48ac81e32d886c5374c451901ed3d',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/0b56fbbeea3261e8ed99e8c3cfd3d728.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc96c2455974b6623dd7c7abffa01bad',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/e384b1dcab6653848e8a9b08e60e32db.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5cbfdc35099f88d3f8a53feeb9f1021',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/79ab11786d4bb6c640b7a16be18a2844.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '005072cdf1b0a0097f82b2a689887430',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/285d591b8122351353cd6ec90032d908.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45efe74c77435bca48dc1a1bbc91574d',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/bf36403b1ff4d661180dec47c04bc279.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '932546aff0d4299a207438f79e454b21',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/63e2254791c579b2bcd81f809eb71f06.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '420224f7ba4d6e420add6c451e6ee4b7',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/2000c19dfc072e67fa09ff58d8dff7d3.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b94b053ee0e3843953fe3fe740678223',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/02d9c443a92d013c2ca6dec5837c2905.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9483574b931dad41e5b4d8f383dde9a',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/4fe8f1588d41dcd9e1abd232c3471f3a.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29a0eeb15cafdb60aa9db8daf072d004',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/d2762620c003cc2b196343c8f9463d4d.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7e3e3849ca4fda54d0ea2eaa1325c9b',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/9a40e0df73893fa152607221b60a0b21.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '066483e7ae64084dd6f139a0b2e1494f',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/97e8cfffbaa2825215d014a9efa8f9e1.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b920b5cd5f8d2d597d00b109de510044',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/52162fac2eed6dffcfd518e2966d8d4e.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '144a3e31bab45f0a6abd7eb87806ac73',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/225891c8973d6baa4633ffd1ec8bd749.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1df5eb1b7757751c7bce3eaa19a34dbf',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/bf0adc0f5d7cf623148fffbd4c9bfd6f.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '758cdd34d586defd8c1e1fa5b172f034',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/fb04280a594bb38aefbc89f405969615.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79bdd00bd3043400e93aef8a32d73400',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/6119aa4b3aa7bda7a483afa573bc5efa.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b25454d158fdd3ad62842a7236c25a01',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/067dbe62b825de1b31adcfe23d972a78.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68fe0b2ef10c981e6918cde3c4074f68',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/90d3f8e8a04d302581074a5813c13df2.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7db01bceb34cb12365c589aa59371405',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/9df1f94ac89a714a6a0c07d49a0cc7f8.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5eb5eff44945ac56d81d194fb2e1da4a',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/69d31f610d29594a931d6ab2f1a8c69d.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5589da3ef2a532ea561b53af1205b14',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/d3f3144a3145c73c0e791492e27e12de.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b8cb738d2dc8917f2cd422b7fddc1f8',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/eaf4db84faafd67181b759e5688393af.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8df666fb7cb6c5f82a9695c190a8c108',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/b66acfd3bd8be3bcbe68f98b2ac0f00a.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bfbca154af192d3c3f3248622879eab',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/0998050f05ce7d51a966cee71dcc4118.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40bb4c72a638e8f3fc9ab71c4047f480',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/9ac06898a96dfc38a194ce5f05d2258e.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a8dd21ead74f2ece67dd9c20d12c4de',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/4fb6c7aa91f45f580a393e3e59fcdd76.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'acada7bc0fff14f283359415f435be51',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/05a6521de374c7ac5a6be01a242c0daa.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5edd3f6c85516b9a07275279dda71558',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/5a3ca72db6120186b44dc7567de8280a.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '740b5b1f55854c2f2b8c08d62e198590',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/aa41323e67b545375cfaaa76277819c0.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f4ef1e0a41e125daa51352b5d536fa4',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/bab0b082847d84f5d833fbf5090655da.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08f3c8ac211548582a48e2e174d87ba7',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/5c5e351246b53aafe1c746e39418f3af.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c11876057677ea3c916af3a3760af20',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/56d72c10c235e50d1a639b2e519ebaff.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9b285fe2eecb17bb689c6b129455734',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/5e18be2a47bc14be06bebd7c5401843a.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '800de7089793d4f51b651402d98f56d3',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/146b19bdf3ebc7cffa201bae62de12d1.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'feb6b15a9a22ac4a0a4b8683250a13c0',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/b2ad5169347aac06948bd57c94a01b05.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c81f1e6ed60ed51adca6f5e9aef3900d',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/e9005dec08b161b846c2f7a0f12fc001.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c293cfeeec37886cb062d1baed1a0c81',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/a3f04b4f7d931ad618277e9e928c032e.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a0e91d7c21eb263979c26f65e1568a9',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/1679460cdd4bc0f62d73c674f3c5fbe8.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f290eb70adb34411d109e945236f98b7',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/ea1f820c0916474466f9ce7efd9a150d.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bf0af9480048a58bf76a5afc0840874',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/564b7ab6f117e1728d77fe2d4b0a891f.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bb90acb7c95a02639851784e876f6a3',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/9b7aaf50900bb21b971c0258b1f8e73f.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdff91620bf6f8287be8c84d86c5e103',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/d0e86dc390cf73b6b2959ec5a6fc8cca.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbf98bde297d705af747beccf7d35e93',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/d2551f39a0d236346c4350a7c06f7310.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4c48380d96198afc8c6a98aeb035c23',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/8fe2eef82f8ec33a7e66412eb7cd2c6a.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '278bea280d5b05af619fff7670a1c58e',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/d5eeaf5dd3ddbe6e371318092c24b88f.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9fc4af15fb1623fdf67a134eccf3946',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/a002bc90dda91d4ef088eaf5c6cc6a6b.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a66420631309410bdc37603de6083dff',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/9aa386273461e74861786753610c353a.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2900a36ed98aa8b369153939e05d1eb',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/c33941fb530e54dd3ef8830882d4b4ef.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95239318d23ca518c5d17d0109b0c342',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/a9b571d8a03b7a9374940412fb9bbbdd.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c9d55be78338547b0b882c01aa8a387',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/83b08419f14a8ccb07cd0e9910f5a642.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7426cbf1d6770794c5f4f1b05d94efb5',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/3f906ade8ee8edfb09d27f4d13c35cbb.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42361e893434ddbcd4162d24e0c6b591',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/04f45cc52de94f2a5cefe5eb1bd1c1ab.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c94bc4ae79b81213c36d355e260a66c9',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/e7f39af817c587b0142b7c0787f489ed.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50a71b962b3f6e29acbb883860c5c306',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/174128b62059004be7703fac47c49b20.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab417437328d435920605d1238fa6584',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/3504efa004a30b233709463977768092.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24b273ade7cd200ed9fc5c9506613256',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/50eed5418e72292cbb80a4fca2a9136f.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '592878def06d143bab5ee8d593690a4a',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/813686bfbe5ec90c72cdf7eb3731cfe0.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '006204ec5d5cce064e547640f9871725',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/047ba9a2f360d484a584a63f90253443.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b314d8df9819f90fce48705244e4c83',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/5ed5bd8d7881c84ced5b06202246d6da.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f565c3e0105832e716638066f51b3f60',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/e6eab4f5a9add625645db11ae721be0b.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7862ac273eeda2ea93ab4dbcb93f803',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/4bb0c25fce225f0f5c479e24bd0e2a82.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28820122549930858d9cccaa559413a5',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/e0800a8849fcbf5580874bb9e2ea70c0.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f79c98261b783e9bc858aa29ca96cb13',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/33da5132d21035e13f48dcf75d54bc44.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa31aad1e89c9a6106e3a7389f1cb5d3',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/5511ce11b3c1bbc356d59b0c61047f44.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '797cf67ff9cad4627d1a48b5703ca955',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/1fdc0ade9c4504d5880c3d50d5b8c624.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '739641b1445f32305416f9e5209af645',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/cfacedd5ae3f129c6fb233e2fb7a5bf8.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f79677eb83a83300b051257dca9ced3e',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/00a27dfd26a036bbf5de7451ca060842.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8490d867bd449415a74477a2c162fc6',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/6d551b659e8d34a55354f65f5f1a9952.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd84155c197c10f66f6947dc3a5f37da0',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/e18c1d7eac7be3146885f1c61376b3e0.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30976ca4191baf719bc8f2a5f2507211',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/0d88da89d43bd43464596fd98655404f.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5076c8541f7f995e1cb7e12aba580c90',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/5f9c957ee2666451a3fab31ebf97400d.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c6da173f87edb69d1999e5b4c2435cc',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/d77acd9b34d2c577f9e4f6de7a0f5978.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65ba86518d91463caa3c60fb987cc9dc',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/71a97b12a34be931295ffc618e9c69ea.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce4b46c051bdb86fdad12fe5b5b86846',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/28ff0bb5e8f56c37d47cf39d1d6d43f1.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '996733eb0821dd238d71f66da88d176c',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/90cb3f94fd5dc78cd180b7fdfa197dcb.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c29baf0a56de08edc4558d34ca489c5',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/74cf2e57f863d6b75177b998ab81269a.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eaced3f4a431e207de9e90e1e34d3b30',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/8301a34d22a7069a04cd71ee2a048e98.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec9061649b9c103d7444983cc4b2b297',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/e7bec98ce4c77d55039e396cec54e5cd.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9a624631d4c56336f3cdc7048f9cff0',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/07164903d0602a68ed18d4756078b843.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5c71f5273fe68aeb5eedff7f0ec6afb',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/34c94b950723feef58a4ded911094f5b.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e881fbf5bb6d8ac5db5009b13ffa559a',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/94472cf36d0119af04eee7ab9d49d44c.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd2ce957477a00e40748f1fc55320f2b',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/93095274a414fb661c3a747d50f4fb8f.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '998e7308acdeac2c83e6af3c3858b4b3',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/ca8fa46505a2c11c3f82fb408d0718e2.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf676d6cebbb00729857a92b6f94c8a5',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/4d21c4abf1d3e5fa41ac91702d10f435.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31f1d96a6a53f787ef3338a38b56dbbb',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/56e58d629a6f7a0bb6daf0141ad204d3.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '880ad449cbf88bede3a1aabfcda15a04',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/abbaa70ccd1e3a56d5d688a52ac9a47b.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '79659e6b13db52db8709c3c59ffd1167',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/3e67f695a7fe938e8b98106c60378a8b.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '39e427019c5e9d1e509a25eae1d3b797',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/fe6994b99e8dc45eccf6c1f001d1991c.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '33dd65f7f17469af0a8c5299ac6083d2',
      'native_key' => 1,
      'filename' => 'modUserGroup/31f00bd1eda05b8a684bb1eae03257e0.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '5e818f4b6888577abdc6c78066d9b63e',
      'native_key' => 1,
      'filename' => 'modDashboard/337162995ccc1ae99008bc63ed7402fa.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'd7951b2135be5135b83c9aa8382bd3d0',
      'native_key' => 1,
      'filename' => 'modMediaSource/8516a9dd20da0c5828b302d14ead0ede.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '300713399ea91508c03803ce2b849016',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/5b62b2d539dd9dead0d7866bc94eeedf.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'bca09d61aaa151ab1daccc66e8b3dd1b',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/7c8c390382068a26607514d932450c8c.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'da02e564a9dd4137e7f25b6f5d819433',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/18048d53dd9b640b43835a30c549b977.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '625b415d93b3ee956c466cbb9ce0cca5',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/2e3df83bdafaa93e4fc0ff0b9347f3b3.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '484e07e42abca18bae9d317661da8518',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/c75b8ea6ebd6a2d86c94fe0997199472.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '677b7d29dd011157f73fd67c3e3d927e',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/b90bd9359b37cc7d86e18fb018c940e2.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '8408e30cb14d618791bb01967fa0fee6',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/d464e1725a30c6f80211feb82ba548a7.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '25f49b03b691ccf35b7f510bab814fa4',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/25a2a5553936d754cab4a2205a5c1107.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ce72783a1c0f666923013fb0045a7404',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/d32b5cd15d730b6188c3f340d629dfb2.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'e1b646f1038fe66bcdece2363e1ec01e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/e8d1baf03abef2c6d68a99df247c9b68.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '3bea417547af28dfe6dff21daac9c06d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/06801fb95f99c9779edcf55c9a6fa624.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '06eaec9737324148bcb4055a118223c8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/a0bb71fbc7b373eeed33cff202515013.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '231e7af5a0ad51b21e9aa68aff7f1fce',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/2db1418f89b355b668565a2442d0487c.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '8fdb18b9aa6dedb7fb4bd0b93d804eb1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1424b374475c4139fb1b8238ebeb2a72.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '082075ccc6387649c64e1dd3f296529a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f19683bb74c61ae241ea3b9ce82da094.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'cdc8ef4182ba41057b7aa1c0cc6a3574',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/fca701f79239c3a7761291c6e764931d.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6dceb63e8279af1407d36cab50a44e9d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/8d52d017fb5243e94a9ab128945bc556.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '44a83df5a2db6e694c7a1d506beedb40',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/5af219b7d114d09bd1889d2985227862.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'f29bbb5e59b1ea1d98bdf34e16eebfbb',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/9f38ae3717423724614cf6c4c1b01d2d.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'fe3b4b9e4cb7590a3b81c5dcc4ec73cd',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f582a5e54f8cca820b822114a63d61ea.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2f96fc80ec60275ac517bb480d002f20',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/6e131cbb04e2ea6a0b6d7e655407e2eb.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b38851e6e2b8fbc4c80ab400a808e84c',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/84ab55ce525657c91366ba45d49251ce.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9366371103eb736164a5124e5bc37850',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/f5ec498026e1bdd576110271055b4119.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1b0b08ecfd47828e83052320b57e6716',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/cbc1b7d1174f9e905d66cd5e4f2b40d8.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '118297928c169359402f20eb7bca89d5',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/2871dec2965e92fe3bd288642683eeda.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '015b811baf167318278584f4302981f8',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/2d4addce1ab586bbbff17b26b9970a11.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a511a5ef5d24c25f47cd56e594df8177',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/1e2f3f2e4e59f4262520a6b5298bb807.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1f3c0c259832745ef2cdc0d898957470',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/a60842431e1eeab45cc8a768972713a3.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a6b4e36faadf9f1293afcfaa087f5d36',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/a2721a8be362b412aa65ab28f0cf2471.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9c826deaa92e92331d03ff506a14a4fd',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/f31b8898c0166a3aff75d9927c419417.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8d7e21a8092cdd56cd1bdbae31dd97f7',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/73e9f86e3b7727c8411c3e19d76dba4f.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'af06ea7db896a5db13f2a064c117f041',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/f99972279e3805ae92c86de3e7aaffc0.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '1adf0b2848f98054869518f44a4957b1',
      'native_key' => 'web',
      'filename' => 'modContext/d07e3c1e5466a7f2e82f3ab87a4ac758.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '0c446d501bae59a677455e389bc5c627',
      'native_key' => 'mgr',
      'filename' => 'modContext/ba353fef81d8f4a23311878cb48f65e6.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b4875d68b658e709857743e355047041',
      'native_key' => 'b4875d68b658e709857743e355047041',
      'filename' => 'xPDOFileVehicle/e789b417750ea9e3d30dc7519e55a588.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e7b2fdd7221e98854607ab7516a68092',
      'native_key' => 'e7b2fdd7221e98854607ab7516a68092',
      'filename' => 'xPDOFileVehicle/9451c2e62cd7e95f5168022db807dcc5.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '99af7ce7486119393b2e4c7be4a0bd30',
      'native_key' => '99af7ce7486119393b2e4c7be4a0bd30',
      'filename' => 'xPDOFileVehicle/ba5ad82ae0e8627f9da39dd1f41fe6c6.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '8585100a1ae311adca4cad30c3878f7c',
      'native_key' => '8585100a1ae311adca4cad30c3878f7c',
      'filename' => 'xPDOFileVehicle/85b76b35f7035e5986d9493c41c637ca.vehicle',
    ),
  ),
);